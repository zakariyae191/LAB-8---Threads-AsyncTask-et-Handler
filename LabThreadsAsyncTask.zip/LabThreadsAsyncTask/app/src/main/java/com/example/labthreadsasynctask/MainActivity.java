package com.example.labthreadsasynctask;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    // Références vers l'interface graphique
    private TextView txtStatus;
    private ProgressBar progressBar;
    private ImageView img;

    // Handler lié au Main Thread / UI Thread
    private Handler mainHandler;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Liaison XML -> Java
        txtStatus = findViewById(R.id.txtStatus);
        progressBar = findViewById(R.id.progressBar);
        img = findViewById(R.id.img);

        Button btnLoadHandler = findViewById(R.id.btnLoadHandler);
        Button btnLoadRunUi = findViewById(R.id.btnLoadRunUi);
        Button btnCalcAsync = findViewById(R.id.btnCalcAsync);
        Button btnToast = findViewById(R.id.btnToast);

        // Création du Handler qui permet de revenir au UI Thread
        mainHandler = new Handler(Looper.getMainLooper());

        // Bouton Toast : il doit répondre immédiatement
        btnToast.setOnClickListener(v ->
                Toast.makeText(getApplicationContext(), "UI réactive", Toast.LENGTH_SHORT).show()
        );

        // Exemple 1 : Thread + Handler.post(...)
        btnLoadHandler.setOnClickListener(v -> loadImageWithHandler());

        // Exemple 2 : Thread + runOnUiThread(...)
        btnLoadRunUi.setOnClickListener(v -> loadImageWithRunOnUiThread());

        // Exemple 3 : AsyncTask pédagogique
        btnCalcAsync.setOnClickListener(v -> new HeavyCalcTask().execute());
    }

    // --------------------------------------------------
    // PARTIE 1 : Worker Thread + Handler.post(...)
    // --------------------------------------------------

    private void loadImageWithHandler() {

        // Cette partie est exécutée sur le UI Thread
        progressBar.setVisibility(View.VISIBLE);
        progressBar.setProgress(0);
        txtStatus.setText("Statut : chargement image avec Handler...");

        // Création d'un Worker Thread
        new Thread(() -> {

            // Travail long simulé en arrière-plan
            try {
                Thread.sleep(1000);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }

            // Chargement de l'image dans le Worker Thread
            Bitmap bitmap = BitmapFactory.decodeResource(getResources(), R.mipmap.ic_launcher);

            // Important :
            // On ne doit pas modifier l'interface directement ici.
            // On revient au UI Thread avec Handler.post(...)
            mainHandler.post(() -> {
                img.setImageBitmap(bitmap);
                progressBar.setVisibility(View.INVISIBLE);
                txtStatus.setText("Statut : image chargée avec Handler");
            });

        }).start();
    }

    // --------------------------------------------------
    // PARTIE 2 : Worker Thread + runOnUiThread(...)
    // --------------------------------------------------

    private void loadImageWithRunOnUiThread() {

        // Cette partie est exécutée sur le UI Thread
        progressBar.setVisibility(View.VISIBLE);
        progressBar.setProgress(0);
        txtStatus.setText("Statut : chargement image avec runOnUiThread...");

        // Création d'un Worker Thread
        new Thread(() -> {

            // Travail long simulé
            try {
                Thread.sleep(1000);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }

            // Chargement de l'image en arrière-plan
            Bitmap bitmap = BitmapFactory.decodeResource(getResources(), R.mipmap.ic_launcher);

            // Solution alternative :
            // runOnUiThread permet aussi de revenir au UI Thread
            runOnUiThread(() -> {
                img.setImageBitmap(bitmap);
                progressBar.setVisibility(View.INVISIBLE);
                txtStatus.setText("Statut : image chargée avec runOnUiThread");
            });

        }).start();
    }

    // --------------------------------------------------
    // PARTIE 3 : AsyncTask pédagogique
    // --------------------------------------------------

    private class HeavyCalcTask extends AsyncTask<Void, Integer, Long> {

        // Avant le traitement : exécuté sur le UI Thread
        @Override
        protected void onPreExecute() {
            progressBar.setVisibility(View.VISIBLE);
            progressBar.setProgress(0);
            txtStatus.setText("Statut : calcul lourd avec AsyncTask...");
        }

        // Traitement long : exécuté sur un Worker Thread
        @Override
        protected Long doInBackground(Void... voids) {
            long result = 0;

            for (int i = 1; i <= 100; i++) {

                // Simulation d'un calcul lourd
                for (int k = 0; k < 20000; k++) {
                    result += i * k % 7;
                }

                // Envoie la progression vers le UI Thread
                publishProgress(i);
            }

            return result;
        }

        // Pendant le traitement : exécuté sur le UI Thread
        @Override
        protected void onProgressUpdate(Integer... values) {
            progressBar.setProgress(values[0]);
        }

        // Après le traitement : exécuté sur le UI Thread
        @Override
        protected void onPostExecute(Long result) {
            progressBar.setVisibility(View.INVISIBLE);
            txtStatus.setText("Statut : calcul terminé, résultat = " + result);
        }
    }
}
